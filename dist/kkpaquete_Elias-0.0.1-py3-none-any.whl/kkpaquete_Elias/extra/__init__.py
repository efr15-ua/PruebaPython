from .otras import multiplica, divide, pi
